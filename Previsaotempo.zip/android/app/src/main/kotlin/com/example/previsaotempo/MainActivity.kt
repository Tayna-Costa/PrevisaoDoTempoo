package com.example.previsaotempo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
